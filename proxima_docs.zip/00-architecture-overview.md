# Vector DB — Architecture Overview

A from-scratch vector database in Python built around a self-written **HNSW
index** (see the HNSW guide) with **scalar INT8 quantization** as the storage
and distance substrate, validated on the **ANN-Benchmarks** suite.

This is the index document. Read it first, then the focused guides:

| Doc | Covers |
|---|---|
| `01-int8-quantization.md` | Scalar INT8 quantizer: calibration, encode/decode, quantized distance, query handling, rerank. The crux of the design. |
| `02-hnsw-integration.md` | How the provided HNSW index plugs into the quantized store; what changes vs. the reference. |
| `03-storage-and-persistence.md` | Memory layout, on-disk format, ID mapping, what state is stored and how it's serialized. |
| `04-public-api-and-query-pipeline.md` | Public API surface and the end-to-end add/build/search/delete flow. |
| `05-ann-benchmarks-harness.md` | Wrapping the DB for ANN-Benchmarks: datasets, recall@k, QPS, parameter sweeps. |

---

## 1. Design goals and non-goals

**Goals**

- Correct, readable, single-machine vector DB you can reason about end to end.
- 4× memory reduction on vectors via INT8 (vs float32), with recall recovered to
  near-float levels through optional reranking.
- Pluggable metric (L2 / cosine / inner product, the latter two reduced to L2).
- Benchmarkable: produces standard recall-vs-QPS curves on ANN-Benchmarks data.

**Non-goals (explicitly out of scope for v1)**

- Distributed / sharded operation, replication, networking.
- Product quantization (PQ), OPQ, or other multi-codebook schemes — scalar only.
- Transactional durability / WAL. Persistence is snapshot-based.
- Filtered / hybrid search (metadata predicates) — leave a hook, don't build it.

---

## 2. Layered architecture

The system is five layers. Each layer depends only on the ones below it. The
HNSW index sits **above** quantization and never sees float32 — it reads INT8
codes through a distance provider.

```
┌─────────────────────────────────────────────────────────────┐
│ 5. Benchmark harness        ann-benchmarks wrapper, recall@k  │
├─────────────────────────────────────────────────────────────┤
│ 4. Public API / query       add · build · search · delete     │
│                             save · load   (ID mapping here)    │
├─────────────────────────────────────────────────────────────┤
│ 3. HNSW index               graph build + traversal           │
│                             (Alg 1–5 from the HNSW guide)      │
├─────────────────────────────────────────────────────────────┤
│ 2. Distance provider        quantized L2 / IP over INT8 codes │
│                             query encoding, optional rerank    │
├─────────────────────────────────────────────────────────────┤
│ 1. Quantized vector store   INT8 codes (+ optional float32),   │
│                             per-dim scales, calibration params │
└─────────────────────────────────────────────────────────────┘
```

The single most important architectural fact: **the HNSW reference's `l2(q,
data[e])` becomes a call into layer 2, and `data[e]` becomes an INT8 code from
layer 1.** Get that seam right (doc 02) and the rest follows the HNSW guide
almost verbatim.

---

## 3. Component responsibilities

**Quantized vector store (layer 1)** — owns the raw bytes. Holds the `(N, D)`
INT8 code matrix, the per-dimension quantization parameters (scale, min), and
optionally the `(N, D)` float32 matrix used only for reranking. Addressable by
dense internal id. Knows nothing about graphs or queries.

**Distance provider (layer 2)** — the quantized-distance kernel HNSW runs,
exposed as the callable passed to its `distance=` parameter: it turns two INT8
code rows into a comparable distance (doc 02 §2). The surrounding concerns —
encoding an incoming query into a code once, and reranking a candidate set back to
float32 — live at the API boundary (doc 04) so HNSW stays a pure graph-over-codes
component.

**HNSW index (layer 3)** — the provided algorithms, unchanged in structure. With
the new `distance=` parameter it takes a **quantized-distance callable** at
construction (no call-site edits), and reads codes through a reference to the
store's code matrix. Owns the graph: `layers`, `entry_point`, `top_layer`, level
RNG, `M`/`ef`, and the **declared metric** (`"l2"`/`"cosine"`), which is persisted
and drives cosine normalization.

**Public API / query (layer 4)** — the user-facing surface. Maps external keys
(UUIDs, row ids) ↔ internal ids, orchestrates add → quantize → insert, runs
search → rerank → map-back, and handles save/load and the delete strategy.

**Benchmark harness (layer 5)** — adapts the API to the ANN-Benchmarks contract
(`fit`, `query`, `set_query_arguments`), loads HDF5 datasets, and measures recall
and throughput.

---

## 4. End-to-end data flow

**Ingest / build**

```
float32 vector ──► [calibrate quantizer on a sample, once]
               ──► encode to INT8 code ──► store code (+ optional float32)
               ──► HNSW.insert(internal_id)   # graph wired using quantized dist
external key ──► assign internal id ──► record in id maps
```

**Query**

```
float32 query ──► encode to INT8 (same params)
              ──► HNSW.search → top-`ef` internal ids   (quantized distance)
              ──► [optional] rerank top-`rerank_k` on float32 ──► top-K
              ──► map internal ids back to external keys ──► return
```

The build path quantizes *before* insertion so the graph topology reflects the
distances the query path will actually use. Building on float32 and querying on
INT8 would mismatch the graph against the runtime metric and cost recall.

---

## 5. Module layout (suggested)

```
vectordb/
├── quantizer.py        # ScalarQuantizer: calibrate / encode / decode / params
├── store.py            # QuantizedStore: code matrix, float matrix, scales
├── distance.py         # DistanceProvider: quantized L2/IP, query encode, rerank
├── hnsw.py             # HNSW index (Alg 1–5), distance-provider injected
├── index.py            # VectorIndex: public API, id mapping, orchestration
├── persistence.py      # save/load: header + blobs + adjacency
├── metrics.py          # l2 / ip / cosine reductions, brute-force baseline
└── bench/
    └── ann_wrapper.py  # ANN-Benchmarks adapter
```

This mirrors the layers in §2 one-to-one, which keeps the dependency arrows
pointing strictly downward and makes each piece unit-testable in isolation.

---

## 6. Recommended defaults (and where they're justified)

| Decision | Default | Rationale | Alternatives (see) |
|---|---|---|---|
| Quantization granularity | Per-dimension | Best accuracy on real embeddings with uneven per-dim ranges. | Global scalar for pure-integer ranking — `01` §3 |
| Code type | `uint8` asymmetric (min/max) | Full 256 levels, simple calibration. | symmetric `int8` for IP — `01` §3 |
| Query distance mode | Symmetric (quantize query too) | Integer math, numpy-vectorizable, fast enough in Python. | Asymmetric (float query) — `01` §6 |
| Reranking | On, `rerank_k = max(ef, 4·K)` | Recovers ~all recall lost to quantization; cheap on a small candidate set. | Off (4× memory, lower recall) — `01` §7 |
| Keep float32? | Yes (for rerank) | Required for rerank; drop it only if memory-bound. | Codes-only mode — `03` §2 |
| Metric | `distance=` callable; cosine via normalize → L2 | One quantized kernel for both metrics; matches the HNSW guide §6.1. | native built-in `"cosine"` (float) — `02` §4 |
| Metric reduction | cosine/IP → L2 on normalized | Asymmetric SQ cancels for L2, not for dot products. | native IP — `01` §8 |
| Delete strategy | Tombstone + periodic rebuild | Simplest correct option; HNSW has no clean in-place delete. | repair-on-delete — `04` §6 |

These are the choices the rest of the docs assume. Each is reversible behind the
layer boundary in §2, so you can start here and swap later without touching HNSW.

---

## 7. Suggested build order

1. **Quantizer** (doc 01) standalone: calibrate on a sample, encode/decode,
   verify reconstruction error is small. Unit-test round-trip.
2. **Store + distance provider** (01, 03): codes in a numpy matrix, quantized L2,
   compare quantized distance ranking to float L2 ranking on random pairs.
3. **HNSW over the store** (02): take the reference index, inject the distance
   provider, build on a small set, validate **recall against brute force** (the
   harness in the HNSW guide §9) — expect a small drop vs float-HNSW.
4. **Rerank** (01 §7): confirm recall climbs back toward float levels.
5. **Public API + id mapping + persistence** (04, 03): save/load round-trips an
   index without re-insertion.
6. **ANN-Benchmarks wrapper** (05): run on a small dataset (e.g. SIFT-1M subset),
   sweep `ef`, plot recall vs QPS.

Do not optimize before step 3 validates recall. A quantization bug and an HNSW
bug both show up as low recall; isolate them by testing layers bottom-up.

---

## 8. The cross-cutting invariants

Carry these through every layer; they're the ones that silently corrupt results:

- **One metric per index, declared at construction and persisted.** The graph
  topology is metric-specific. The declared metric (`"l2"`/`"cosine"`) drives
  normalization (unit-length for cosine, on both insert and query) and the
  quantizer is calibrated in that same space. Never mix, never query with a
  different metric than the index was built with.
- **Same quantization params on insert and query.** The query must be encoded
  with the exact scales/mins used to encode the stored vectors, or distances are
  meaningless.
- **Quantized distance need only be *monotonic* in true distance for ranking.**
  Absolute values are wrong (they're approximations); only the ordering matters
  for HNSW traversal. Convert to true distance only when exposing it to users.
- **Internal ids are dense and HNSW-owned; external keys live in the API layer.**
  HNSW must never see a UUID.
- **All the HNSW invariants from the guide still apply** (symmetric edges, the
  shrink step, `Mmax0 = 2M`, `ef ≥ K`, entry-point update rule). Quantization
  changes *distances*, not the graph algorithm.
