# 01 — Scalar INT8 Quantization

This is the load-bearing part of the design. Scalar quantization (SQ) maps each
float32 vector to a vector of 8-bit integers, cutting memory 4× and making
distance computation integer/SIMD-friendly. The HNSW graph is built and traversed
entirely over these codes; full-precision vectors (if kept) are used only to
*rerank* a small candidate set at the very end.

> **Mental model.** SQ approximates each coordinate with one of 256 evenly spaced
> levels inside that coordinate's observed range. The approximation is good
> precisely because real embedding coordinates are bounded and roughly
> well-distributed. Where they aren't (heavy tails), you clip.

---

## 1. What "scalar" means here

Each dimension `j` is quantized independently with an affine map

```
encode:   q_j = clamp( round( (x_j - min_j) / s_j ),  0, 255 )      # uint8
decode:   x̂_j = min_j + q_j · s_j
scale:    s_j = (max_j - min_j) / 255
```

Contrast with **product quantization** (splits the vector into sub-vectors, each
mapped to a learned codebook entry). PQ compresses far more but is much more code
and a different distance scheme. This design is scalar only; PQ is a future doc.

---

## 2. Calibration (fitting the quantizer)

The quantizer has parameters `min_j` and `s_j` per dimension. Fit them **once**,
before any insertion, from a representative sample.

```python
import numpy as np

class ScalarQuantizer:
    def __init__(self, per_dim=True, clip_pct=0.0):
        self.per_dim = per_dim          # False => single global scale
        self.clip_pct = clip_pct        # e.g. 0.1 trims to [0.1, 99.9] pct
        self.min_ = None                # (D,) or scalar
        self.scale_ = None              # (D,) or scalar  (== s_j)
        self.scale2_ = None             # s_j**2, precomputed for distance

    def fit(self, sample):              # sample: (n, D) float32
        x = np.asarray(sample, dtype=np.float32)
        if self.clip_pct > 0:
            lo = np.percentile(x, self.clip_pct, axis=0)
            hi = np.percentile(x, 100 - self.clip_pct, axis=0)
        else:
            lo, hi = x.min(axis=0), x.max(axis=0)
        if not self.per_dim:            # collapse to one global range
            lo, hi = lo.min(), hi.max()
        scale = (hi - lo) / 255.0
        scale = np.where(scale == 0, 1e-12, scale)   # constant dims -> no div0
        self.min_, self.scale_ = lo.astype(np.float32), scale.astype(np.float32)
        self.scale2_ = (self.scale_ ** 2).astype(np.float32)
        return self
```

**Sample size.** A few × 10⁴ vectors is plenty to estimate per-dim ranges; you do
not need the whole dataset. On ANN-Benchmarks, calibrate on the train split (or a
random 50–100k subset of it).

**Clipping (`clip_pct`).** Without it, a single outlier coordinate stretches that
dimension's range so the other 99.9% of values collapse into a few quantization
levels — catastrophic for that dim's resolution. Trimming to the 0.1/99.9
percentiles and clamping on encode is the standard fix. Start at `clip_pct=0` and
turn it on if reconstruction error is dominated by a few dims.

**Constant dimensions.** If `min_j == max_j`, `s_j = 0`. Guard it (set to a tiny
epsilon); the dimension then contributes ~0 to every distance, which is correct.

---

## 3. Per-dimension vs global — the key tradeoff

| | Per-dimension (default) | Global (single scale) |
|---|---|---|
| Accuracy | High — each dim uses its full 256 levels | Lower — wide dims starve narrow dims of levels |
| Distance cost | Weighted: `Σ s_j² (a_j−b_j)²` | Plain int: `Σ (a_j−b_j)²`, rank directly |
| When | Real embeddings (uneven ranges) | Pre-normalized data, dims share a range |
| ANN data | GloVe, GIST, deep embeddings | SIFT (already 0–255, near-uniform) |

The global mode buys a genuinely faster inner loop because the constant `s²`
factor drops out of *ranking* — you compare raw integer sums. Use it when the
data is naturally homogeneous across dimensions; otherwise per-dimension wins on
recall by enough to be worth the multiply.

---

## 4. Encoding and decoding

```python
    def encode(self, x):                # x: (..., D) float32 -> (..., D) uint8
        q = np.round((x - self.min_) / self.scale_)
        return np.clip(q, 0, 255).astype(np.uint8)

    def decode(self, q):                # q: (..., D) uint8 -> (..., D) float32
        return self.min_ + q.astype(np.float32) * self.scale_
```

`encode` is applied to every vector on insert and to every query. `decode` is
used **only** for reranking and for any user-facing distance, never inside the
HNSW traversal hot loop.

---

## 5. Quantized L2 distance (the derivation that matters)

For two stored vectors approximated by codes `a`, `b`:

```
x̂_j − ŷ_j = (min_j + a_j·s_j) − (min_j + b_j·s_j) = (a_j − b_j)·s_j
‖x̂ − ŷ‖²   = Σ_j (a_j − b_j)² · s_j²
```

The `min_j` offset **cancels** in the difference — this is why asymmetric (min/max)
quantization is fine for L2 even though it has a per-dim bias. The distance is a
per-dimension *weighted* squared integer difference:

```python
def l2_codes(a, b, scale2):             # a,b: (D,) uint8 ; scale2: (D,) float32
    d = a.astype(np.int16) - b.astype(np.int16)   # int16: |diff| <= 255, safe
    return float(np.dot((d * d).astype(np.float32), scale2))
```

For the **global** mode, `scale2` is a scalar; ranking can drop it entirely and
compare `np.dot(d, d)` (int) directly.

**Overflow note.** `uint8 − uint8` underflows; cast to `int16` first. `d*d` peaks
at `255² = 65025`, summed over D — use `float32`/`int32` accumulation, not int16.

**Optional speedup (norm decomposition).** `Σ s²(a−b)² = Σ s²a² − 2Σ s²ab + Σ s²b²`.
Precompute each vector's `Σ s²a²` once at insert; then a distance is a weighted
dot plus two cached norms. Worth it only after correctness is proven — see the
HNSW guide's "replace data structures" step.

---

## 6. Query handling — symmetric vs asymmetric

The HNSW loop computes `dist(query, stored_id)` thousands of times per search. Two
ways to handle the query side:

**Symmetric (SDC) — default.** Quantize the query *once* with the same params,
then every distance is code↔code via `l2_codes`. All integer math, fully
vectorizable, and the query-encode cost is amortized over the whole search.

**Asymmetric (ADC).** Keep the query in float32 and compare against
*decoded* stored vectors: `‖q_float − decode(b)‖²`. Slightly more accurate (no
query-side rounding) but you either decode on the fly (slow) or precompute a
per-dimension lookup table `LUT[j][code] = (q_j − (min_j + code·s_j))²` and sum
`Σ_j LUT[j][b_j]`. The LUT is the proper ADC implementation and is competitive,
but it's more machinery.

Recommendation: **symmetric** for v1. The query-side rounding error is tiny
relative to the storage rounding you already accept, and reranking erases it.
Reach for ADC+LUT only if a recall sweep shows the symmetric query rounding is
the binding constraint (it usually isn't).

---

## 7. Reranking — recovering the recall quantization costs you

Quantization makes the *graph traversal* approximate twice over (approximate
nearest neighbor on approximate distances). Reranking fixes the second part
cheaply:

```
1. HNSW.search returns the top `rerank_k` internal ids by *quantized* distance.
2. Recompute *exact float32* L2 for just those `rerank_k` candidates.
3. Re-sort, return the top K.
```

```python
def search_with_rerank(provider, query_f32, K, ef, rerank_k):
    cand = provider.hnsw.search(provider.encode(query_f32), rerank_k, ef=ef)
    if provider.float_store is None:        # codes-only mode: skip rerank
        return cand[:K]
    f = provider.float_store[cand]          # (rerank_k, D) float32
    d = np.sum((f - query_f32) ** 2, axis=1)
    order = np.argsort(d)[:K]
    return [cand[i] for i in order]
```

`rerank_k` of `max(ef, 4·K)` recovers most of the gap to float-HNSW at negligible
cost (a few hundred exact distances). It costs you the float32 store (4× the code
memory). If you're memory-bound and drop float32, you lose rerank and accept the
lower recall — quantify it with the harness before deciding.

This decomposition is also a clean debugging axis: **float-HNSW recall** (no
quantization) isolates HNSW bugs; **quantized recall without rerank** measures
pure quantization loss; **with rerank** is your shipping number.

---

## 8. Metrics other than L2

- **Cosine.** The HNSW index now offers a native `distance="cosine"`, but in the
  *quantized* DB we follow the guide's §6.1 production advice: normalize every
  vector to unit length *before* calibration and *before* every encode (insert and
  query). Then cosine ranking ≡ L2 ranking, the whole L2 path above applies
  unchanged, and HNSW runs the same `QuantizedL2` callable (doc 02 §4). Calibrate
  on normalized samples. This keeps one quantized kernel for both metrics and
  avoids the dot-product non-cancellation below.
- **Inner product (MIPS).** Asymmetric SQ does **not** cancel cleanly for IP (the
  `min_j` cross-terms survive), so either (a) use *symmetric* SQ (`min_j = 0`,
  `s_j = absmax_j/127`, `int8`) giving `⟨x,y⟩ ≈ Σ s_j² a_j b_j`, or (b) if your
  vectors can be unit-normalized, reduce MIPS to L2/cosine. Prefer (b) when valid.
- **Zero vectors** break cosine normalization (divide by zero). Decide policy:
  reject, or map to a sentinel. Same caveat as the HNSW guide.

Pick one metric per index and bake it into the quantizer and the distance
provider together — they must agree on the vector space.

---

## 9. Validation specific to quantization

Beyond the end-to-end recall harness, test the quantizer in isolation:

- **Reconstruction error.** `mean ‖x − decode(encode(x))‖ / ‖x‖` over a held-out
  sample. Expect small (single-digit %); a spike points at missing clipping or a
  bad calibration sample.
- **Ranking agreement.** For random query/pair triples, check that
  `l2_codes` orders pairs the same as float L2 most of the time (Kendall-τ or
  simple inversion count). This catches scale/overflow bugs before they hide
  inside HNSW recall.
- **Distance monotonicity.** `l2_codes` should increase with true L2 on a sweep of
  perturbed vectors. A non-monotone result means a sign/overflow error.

---

## 10. Quantization pitfalls (the ones that bite)

1. **Calibrating on query data or on too small / unrepresentative a sample.** Fit
   on the same distribution you'll store. Garbage ranges → garbage codes.
2. **Forgetting to clamp on encode.** Out-of-range values (especially queries
   outside the calibration range) overflow `uint8` and wrap around. Always
   `np.clip(..., 0, 255)`.
3. **`uint8` subtraction underflow.** Cast to `int16` before differencing. This is
   the single most common silent bug.
4. **Different params on insert vs query.** Re-fitting or re-deriving scales per
   batch desynchronizes the space. Fit once, freeze, persist the params.
5. **Per-dim scale dropped from the distance.** With per-dim quantization you
   *must* weight by `s_j²`; ranking on raw integer diffs is only valid in global
   mode. Mixing these tanks recall on uneven data.
6. **Reranking against the wrong store.** Rerank must use float32, not decoded
   codes (decoding doesn't recover the lost precision — it returns the same
   approximation). Keep the real float32 vectors if you rerank.
7. **Constant or near-constant dimensions** with `s_j = 0` causing division by
   zero on encode. Guard with epsilon at fit time.
8. **Assuming quantized distances are true distances.** They're approximations,
   valid for *ranking* only. `sqrt` of a quantized squared distance is not the
   real distance — convert from float32 if you expose a number to users.
