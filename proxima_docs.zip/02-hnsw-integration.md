# 02 — HNSW Integration

How the HNSW index plugs into the quantized store. With the **new
`distance=` parameter**, this gets simpler than it used to be: the index already
routes every distance through `self.dist` and accepts a *callable* metric. So you
don't hand-edit call sites — you **inject a quantized-distance callable** and
point `self.data` at the code store. Every structural rule in the HNSW guide
(symmetric edges, the shrink step, `Mmax0 = 2M`, `mL = 1/ln M`, `ef ≥ K`, the
entry-point rule, the two-phase descent) holds verbatim. You change *what the
vectors are* (INT8 codes) and *what the distance callable does* — nothing else.

---

## 1. The seam (now a clean injection point)

The new HNSW exposes exactly the two hooks the quantized DB needs:

1. **`distance=` accepts a callable.** The guide's §6.1 already documents
   `HNSW(..., distance=my_metric)` where `my_metric(a, b) -> float`, smaller =
   closer, compared only within one index. Our quantized distance is just such a
   callable. No need to touch `_search_layer`, `_select_neighbors`, `insert`, or
   `search` — they all call `self.dist(a, b)` on whatever `self.data` holds.
2. **`self.data[i]` is the vector store.** Point it at the INT8 code matrix and
   every `self.dist(q, self.data[e])` becomes a code↔code quantized distance for
   free.

So the integration is three things, none of which alter the algorithm:

- Pass a **quantized-distance callable** as `distance=`.
- Make `self.data[i]` return an **INT8 code** (a row of the store's code matrix).
- Feed **already-encoded codes** into `insert`/`search` (the API layer encodes
  once at the boundary — doc 04).

That last point is why the metric callable sees codes, not floats: encoding
happens before HNSW is ever called.

---

## 2. The quantized distance callable

`distance=` wants a 2-arg callable over whatever lives in `self.data`. In the
quantized index that's two INT8 code rows. The callable carries the per-dimension
`scale²` (doc 01 §5):

```python
import numpy as np

class QuantizedL2:
    """Drop-in for HNSW's `distance=`: weighted squared int distance over codes.
       Smaller = closer, which is all HNSW requires."""
    def __init__(self, scale2):            # (D,) float32, or scalar in global mode
        self.scale2 = scale2

    def __call__(self, a, b):              # a, b: uint8 code rows
        d = a.astype(np.int16) - b.astype(np.int16)   # int16: avoid uint underflow
        return float(np.dot((d * d).astype(np.float32), self.scale2))
```

Construct the index with it, and point `data` at the store's code matrix:

```python
from hnsw import HNSW                       # the reference index, unmodified

dist  = QuantizedL2(quantizer.scale2_)
index = HNSW(M=16, efConstruction=200, distance=dist, seed=0)
index.data = store.codes                    # self.data[i] -> uint8 code row (id i)
```

`index.data` is a **reference** to the store's code matrix (doc 03), not a copy —
the store stays the single owner of the codes. HNSW holds ids and edges and reads
codes through this reference. This is the only place the two layers touch.

> Because the metric is a plain callable, the guide's built-in `"l2"` / `"cosine"`
> registry is *bypassed* in the quantized index — our callable replaces it. The
> declared metric still matters (it drives normalization, §4), but the kernel HNSW
> runs is always this quantized-L2-form callable.

---

## 3. Insert takes an id, not a vector

The reference `insert(vector)` appends the vector to `self.data` and owns it. In
the integrated design the **store owns the vectors**, so `insert` takes an
internal id whose code is *already in the store*. This is the one small edit to
the index body — its first two lines:

```python
# reference:
def insert(self, vector, use_heuristic=True):
    q = len(self.data)
    self.data.append(vector)
    ...

# integrated: the API layer already appended the code to the store at id `q`
def insert(self, q, use_heuristic=True):     # q = internal id
    l = self._random_level()
    ...                                       # everything below is UNCHANGED
```

Everything after those two lines — level draw, two-phase descent, neighbour
selection, symmetric wiring, the shrink step, entry-point update — is **identical
to the guide**, because it only ever touches `self.data[...]` (now codes) and
`self.dist(...)` (now quantized). The diversity test inside
`SELECT-NEIGHBORS-HEURISTIC` (`self.dist(self.data[e], self.data[r])`) runs on
codes automatically; no change needed.

`search(query_code, K, ef)` is likewise unchanged: it takes a **query code**
(encoded at the boundary), traverses on quantized distances, and returns internal
ids ranked by quantized distance. Call it with `K = rerank_k` so the API layer
has candidates to rerank (§5).

---

## 4. Cosine in the quantized index

The new guide adds native `distance="cosine"` and, in §6.1, recommends the
production form: **normalize each vector to unit length once, then cosine ranking
≡ L2 ranking** (reuse the L2 kernel). The quantized index follows exactly that
advice, for two reasons:

- It lets us keep **one quantized kernel** (`QuantizedL2`) for both metrics — the
  cosine-ness lives entirely in a normalization step *before* encoding.
- Asymmetric scalar quantization does **not** cancel cleanly for dot-product /
  cosine distance (the per-dim offsets survive the product), whereas it cancels
  perfectly for L2 differences (doc 01 §5, §8). Reducing cosine to L2-on-unit
  vectors sidesteps that entirely.

So for a cosine index the API layer (doc 04) unit-normalizes every vector on
insert *and* every query, then encodes; HNSW runs the same `QuantizedL2` callable.
The index records its **declared metric** (`"cosine"`) as metadata — it drives the
normalization and is persisted (doc 03) — even though the kernel HNSW executes is
L2-form. Never query a cosine-built index without normalizing the query, and never
mix metrics in one index (the graph topology is metric-specific — guide §6.1).

Zero-magnitude vectors have undefined direction; reject or special-case them
before normalization, as the guide notes.

---

## 5. Search returns ids; the API layer reranks

`search` returns internal ids ranked by **quantized** distance. It must return at
least `rerank_k ≥ K` ids so the API layer can rerank on float32:

```python
raw = index.search(query_code, K=rerank_k, ef=ef)   # ids by quantized distance
# doc 04 then: filter tombstones -> rerank top-K on float32 -> map ids to keys
```

The rerank step (doc 01 §7) lives in the API layer so HNSW stays a pure
graph-over-codes component. The quantized distance is *monotonic* in true
distance, so the greedy traversal and early-stop logic remain correct — rerank
just polishes the final ordering with exact float32 distances.

---

## 6. What explicitly does NOT change

- **Graph structure and algorithms.** Alg 1–5 are structurally identical; the
  only body edit is `insert(id)` not appending (§3).
- **The `distance=` mechanism.** It's a first-class constructor parameter now; we
  pass a callable, which the guide explicitly supports. No call-site surgery.
- **All 14 "points to remember"** from the guide. Re-read them; all still live —
  edge symmetry, the shrink step, `Mmax0 = 2M`, `mL = 1/ln M`, `ef ≥ K`, the
  entry-point rule, seedable per-index RNG.
- **Parameters.** `M`, `Mmax`, `Mmax0`, `mL`, `efConstruction`, `ef` — same
  meanings, same defaults.
- **Complexity.** Still `O(log N)` search / `O(N log N)` build. Quantization
  changes the *constant* (cheaper distances, smaller footprint), not asymptotics.

---

## 7. Integration pitfalls

1. **Building on float32 then querying on codes.** Encode *before* insert so the
   graph encodes the quantized neighborhoods the query path actually uses.
2. **HNSW owning a second copy of the vectors.** `index.data` is a *reference* to
   the store's code matrix; the store is the single owner. Don't append codes in
   two places.
3. **Returning only `K` from `search`.** Rerank needs `rerank_k > K` candidates;
   capping at `K` caps achievable post-rerank recall.
4. **Re-encoding the query per hop.** Encode once at the API boundary; pass the
   code into `search`. Re-encoding inside the loop is pure waste.
5. **Passing a float-space metric as `distance=` while storing codes.** The
   callable must match the stored representation — a code↔code kernel for codes.
   Mixing a float metric with code data silently produces garbage distances.
6. **Forgetting cosine normalization on one side.** Normalize on both insert and
   query, before encoding, or a cosine index is built in a different space than
   it's queried (guide §6.1).
7. **Letting the declared metric and the kernel disagree.** Persist the declared
   metric; use it to decide normalization. The kernel is always quantized-L2-form,
   but the *space* (raw vs unit-normalized) must match the declared metric.
