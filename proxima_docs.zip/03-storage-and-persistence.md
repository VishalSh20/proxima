# 03 — Storage, Memory Layout & Persistence

What state exists, how it's laid out in memory, and how it's serialized. The
design keeps **one source of truth for vectors** (the store) and treats the HNSW
graph as ids-plus-edges that reference it.

---

## 1. State inventory

The complete index state, grouped by owner:

| Owner | State | Type |
|---|---|---|
| Store | `codes` | `(N, D)` `uint8` — the INT8 vectors (HNSW reads these by reference) |
| Store | `floats` (optional) | `(N, D)` `float32` — for rerank only |
| Store | quantizer params: `min_`, `scale_`, `scale2_` | `(D,)` `float32` (or scalar) |
| Store | quantizer config: `per_dim`, `clip_pct` | small scalars |
| HNSW | declared `metric` (`distance=`) | string — `"l2"`/`"cosine"`; drives normalization |
| HNSW | `layers` | per-layer adjacency (id → neighbour ids) |
| HNSW | `entry_point`, `top_layer` | ints |
| HNSW | params: `M`, `Mmax`, `Mmax0`, `mL`, `efConstruction`, seed | small scalars |
| API | `external→internal`, `internal→external` | id maps |
| API | `tombstones` | set of deleted internal ids |

`N` and `D` are derived. `index.data` is a reference to the Store's `codes`
matrix, not a separate copy — codes have one owner. Everything here must
round-trip through persistence (§4) so a loaded index is byte-identical in
behavior to the one that was saved. **Persist the declared metric**: loading a
cosine index that thinks it's L2 (or skipping query normalization) silently
corrupts every result (HNSW guide §6.1).

---

## 2. Memory layout

The HNSW guide's §6.3 ("replace Python data structures") applies directly; here's
the concrete layout for the quantized store.

**Vectors — contiguous typed matrices.**

```python
self.codes  = np.empty((capacity, D), dtype=np.uint8)    # always
self.floats = np.empty((capacity, D), dtype=np.float32)  # only if reranking
self.size   = 0     # number of live rows used
```

Row `i` is internal id `i`. Distance reads `codes[i]` as a contiguous slice —
cache-friendly and numpy-vectorizable. Grow by doubling `capacity` and copying
(amortized O(1) append), the standard dynamic-array trick.

**Memory budget (per vector):**

| Component | Bytes | Note |
|---|---|---|
| INT8 code | `D` | the 4× win vs float32 |
| float32 (if rerank) | `4·D` | dominates if kept; drop to go codes-only |
| graph edges | `~(Mmax0 + mL·Mmax)·4` | int32 ids, per HNSW guide §8 |
| quant params | `~12·D` total (not per vector) | amortized to ~0 |

Codes-only is a true 4× reduction over a float32 flat index. Keeping float32 for
rerank means you're back to ~5× the code size — the rerank store, not the codes,
is your memory floor. That's the explicit recall-vs-memory dial.

**Neighbour lists.** For production speed, replace each `set` with a fixed-size
`int32` array of length `Mmax` (`Mmax0` on layer 0) plus a count, exactly as the
HNSW guide §6.3 prescribes. For a first correct version, the `dict[int, set]` from
the reference is fine; swap it in step 6 of the build order.

**Visited set.** Use the visited-version array (epoch counter) from HNSW guide
§6.3 — a per-query fresh `set` dominates cost at scale.

---

## 3. ID mapping

HNSW and the store both use dense internal ids `0..N−1`. External keys (UUIDs,
row ids, dataset indices) live only in the API layer:

```python
self.ext2int = {}          # external key  -> internal id
self.int2ext = []          # internal id   -> external key  (list, dense)
```

On `add`: assign `internal = store.size`, append the code/float, record both maps,
then `hnsw.insert(internal)`. On `search`: HNSW returns internal ids → map back
through `int2ext` before returning to the caller. HNSW must **never** see an
external key; the store is indexed by internal id only. (HNSW guide §6.2.)

For ANN-Benchmarks the "external key" is just the row index of the train split,
so `int2ext` is the identity and the maps are trivial — but keep the layer so the
API generalizes beyond the benchmark.

---

## 4. Persistence format

Snapshot-based (no WAL). Serialize parameters, the id maps, the vector blobs, and
the per-layer adjacency. On load, rebuild in-memory structures directly — **no
re-insertion** (HNSW guide §6.6). Version the format from day one.

**Layout (single file or a small directory):**

```
header (JSON):
  format_version, metric, N, D
  quantizer: { per_dim, clip_pct }
  hnsw: { M, Mmax, Mmax0, mL, efConstruction, seed,
          entry_point, top_layer }
  has_floats: bool

blobs (binary, length-prefixed or fixed-offset):
  min_     : float32[D or 1]
  scale_   : float32[D or 1]
  codes    : uint8[N, D]
  floats   : float32[N, D]        # only if has_floats
  int2ext  : (serialized external keys; JSON if small, else a typed blob)

adjacency:
  for each layer lc in 0..top_layer:
    for each node: node_id, degree, neighbour_ids[degree]   (int32)
```

`scale2_` is derived from `scale_` on load — don't store it. `numpy.save` /
`np.lib.format`, or raw `tobytes()` with offsets recorded in the header, both
work; the header-plus-blobs split keeps the format inspectable and versionable.

**Load** reconstructs: quantizer (params → recompute `scale2_`), store (mmap or
read the matrices), HNSW (params + rebuild `layers` from the adjacency section,
set `entry_point`/`top_layer`), API maps. Validate `N`, `D`, and
`format_version` against the header and fail loudly on mismatch.

**mmap option.** For large indexes, `np.memmap` the `codes` (and `floats`) blobs
so the OS page-cache handles residency instead of loading everything up front.
This is the cheap path to "bigger than RAM" without a real disk-backed graph.

---

## 5. Deletes (storage view)

HNSW has no clean in-place delete (HNSW guide §6.7). Default to **tombstones**:

```python
self.tombstones = set()     # internal ids marked deleted
```

- `delete(external_key)` → look up internal id, add to `tombstones`, drop the id
  maps. The node stays in the graph as a routing waypoint and in the store.
- `search` filters tombstoned ids out of results *after* HNSW returns (fetch a
  few extra candidates to refill K).
- Periodically **rebuild** the index from the live vectors to reclaim space and
  remove dead waypoints, when the tombstone fraction crosses a threshold (say
  20–30%).

The store's matrices don't shrink on delete; rebuild is what compacts them.
Updates = delete + re-add (a changed vector changes its graph neighborhood, so
you can't edit in place — HNSW guide §6.7). Repair-on-delete is the more complex
alternative if rebuilds are too disruptive; see doc 04 §6.

---

## 6. Storage pitfalls

1. **Two copies of the vectors drifting apart.** The store is the sole owner.
   HNSW references ids; it never holds vectors.
2. **Persisting `scale2_` and `scale_` both, then loading inconsistent ones.**
   Derive `scale2_` on load; store only `scale_` and `min_`.
3. **Re-inserting on load.** Rebuild adjacency directly from the saved graph;
   re-insertion is slow and produces a *different* (re-randomized) graph.
4. **Unversioned format.** Put `format_version` in the header before you ship a
   single file; you will change the layout.
5. **Forgetting the id maps in the snapshot.** Without them a loaded index returns
   internal ids that mean nothing to the caller.
6. **Growing matrices by per-row reallocation.** Double the capacity; per-append
   realloc is O(N²) over a build.
7. **mmap + writes.** If you mmap codes read-only for serving, don't also try to
   append through the same mapping. Separate the build-time (writable) and
   serve-time (read-only mmap) paths.
