# 04 — Public API & Query Pipeline

The user-facing layer. It owns id mapping, orchestrates encode → insert and
search → rerank → map-back, and exposes save/load and deletes. Everything below
it (HNSW, distance, store, quantizer) stays vector-space-internal; this layer is
where external keys, float32 queries, and `K` live.

---

## 1. Public surface

```python
class VectorIndex:
    def __init__(self, dim, metric="l2", *,
                 M=16, efConstruction=100, seed=0,
                 per_dim=True, clip_pct=0.0, keep_floats=True):
        ...

    # lifecycle
    def calibrate(self, sample): ...          # fit quantizer (once, pre-add)
    def add(self, key, vector): ...           # one vector
    def add_batch(self, keys, vectors): ...   # many (preferred for build)
    def build(self, keys, vectors): ...       # calibrate + add_batch

    # query
    def search(self, query, K, *, ef=None, rerank_k=None): ...
    def search_batch(self, queries, K, *, ef=None, rerank_k=None): ...

    # mutation
    def delete(self, key): ...
    def rebuild(self): ...                     # compact away tombstones

    # persistence
    def save(self, path): ...
    @classmethod
    def load(cls, path): ...

    # introspection
    def __len__(self): ...                     # live vector count
    def stats(self): ...                       # N, tombstones, layers, mem
```

`metric` is fixed at construction and frozen (graph + quantizer are
metric-specific). It is realized through the HNSW index's `distance=` parameter:
the `VectorIndex` constructs `hnsw = HNSW(M=M, efConstruction=efConstruction,
distance=QuantizedL2(quantizer.scale2_), seed=seed)` and points `hnsw.data` at the
store's code matrix (doc 02 §2). For `metric="cosine"`, the kernel is still
`QuantizedL2` — the cosine-ness lives in the normalization applied before encoding
(§2–§3). `keep_floats=False` drops the rerank store for a 4× footprint and
disables reranking.

---

## 2. Build path

Calibration must happen before any insert, and on a representative sample. The
`build` convenience does both:

```python
def build(self, keys, vectors):
    V = np.asarray(vectors, dtype=np.float32)
    if self.metric == "cosine":
        V = _normalize(V)                      # unit length, then treat as L2
    sample = V if len(V) <= 100_000 else V[self._rng.choice(len(V), 100_000)]
    self.quantizer.fit(sample)                 # freeze params
    self.add_batch(keys, V)                    # encode + insert each
```

```python
def add(self, key, vector):
    v = np.asarray(vector, dtype=np.float32)
    if self.metric == "cosine":
        v = _normalize(v)
    code = self.quantizer.encode(v)            # uint8 (D,)
    internal = self.store.append(code, v if self.keep_floats else None)
    self.ext2int[key] = internal
    self.int2ext.append(key)
    self.hnsw.insert(internal)                 # builds graph on the code
    return internal
```

Order matters: **calibrate → encode → store → insert.** The vector is in the
store (so HNSW's distance calls can read `codes[internal]`) before `insert` runs.
For ANN-Benchmarks, `keys` are just row indices, so the id maps are the identity
— but the code path is the same.

**Parallel build** (HNSW guide §6.5) slots in here: shard `add_batch` across
threads with per-node locks on neighbour-list mutation and a guarded entry-point
update. Calibration is single-threaded and happens first. Defer this until
single-threaded correctness is proven (build order step 8).

---

## 3. Query path

The full pipeline, top to bottom:

```python
def search(self, query, K, *, ef=None, rerank_k=None):
    q = np.asarray(query, dtype=np.float32)
    if self.metric == "cosine":
        q = _normalize(q)
    ef = ef or max(self.efConstruction, K)            # ef >= K (HNSW guide)
    rerank_k = rerank_k or (max(ef, 4 * K) if self.keep_floats else K)

    q_code = self.quantizer.encode(q)                 # encode ONCE
    # over-fetch so tombstone filtering + rerank still yield K
    raw = self.hnsw.search(q_code, n=rerank_k + len(self._recent_tombstones()),
                           ef=ef)
    cand = [i for i in raw if i not in self.tombstones][:rerank_k]

    if self.keep_floats:                              # rerank on float32
        f = self.store.floats[cand]
        d = np.sum((f - q) ** 2, axis=1)
        cand = [cand[i] for i in np.argsort(d)[:K]]
    else:
        cand = cand[:K]

    return [self.int2ext[i] for i in cand]            # map back to keys
```

Five stages: **normalize (cosine) → encode once → HNSW over codes → filter
tombstones → rerank on float32 → map ids back.** Each is a layer boundary from
the overview; you can unit-test them independently.

`ef` and `rerank_k` are pure query-time knobs — no rebuild to change them. This is
what the ANN-Benchmarks sweep varies to trace the recall/QPS curve (doc 05).
`return_distances=True` (optional) should return *float32* distances from the
rerank step, never the quantized approximations (doc 01 §10).

---

## 4. Batch queries

ANN-Benchmarks issues queries one at a time by default, but a batch path is worth
having: encode all queries in one vectorized `encode`, then loop HNSW per query
(the graph traversal is inherently per-query), and rerank can be batched with a
single `(Q, rerank_k, D)` gather if memory allows. The win is amortizing
query-encode and Python overhead, not changing the graph search.

---

## 5. Parameter surface summary

| Param | Set at | Effect | Rebuild to change? |
|---|---|---|---|
| `metric` | construct | vector space + distance | yes (new index) |
| `M`, `efConstruction` | construct | graph quality/build cost | yes |
| `per_dim`, `clip_pct` | construct | quantizer accuracy | yes (re-encode all) |
| `keep_floats` | construct | rerank availability, memory | yes |
| `ef` | per query | recall/speed | **no** |
| `rerank_k` | per query | recall/speed | **no** |
| `K` | per query | results returned | no |

The build/query split mirrors the HNSW guide: `M`/`efConstruction`/quantizer are
baked in; `ef`/`rerank_k`/`K` are free runtime dials.

---

## 6. Delete strategy

Default **tombstone + periodic rebuild** (doc 03 §5):

```python
def delete(self, key):
    i = self.ext2int.pop(key)
    self.tombstones.add(i)
    self.int2ext[i] = None          # key no longer resolvable

def rebuild(self):
    live = [(k, self.store.floats[i]) for i, k in enumerate(self.int2ext)
            if k is not None]
    new = VectorIndex(self.dim, self.metric, M=..., efConstruction=...)
    new.build([k for k, _ in live], [v for _, v in live])
    return new                       # swap in atomically at the serve layer
```

`rebuild` requires `keep_floats=True` (it re-encodes from float32). If you run
codes-only, you can only rebuild by decoding (lossy) — another reason to keep
float32 unless memory forces otherwise.

**Repair-on-delete** is the alternative (HNSW guide §6.7): unlink the dead node
and re-link its orphaned neighbours to each other via the neighbour selector.
More code, no rebuild pauses, keeps the graph clean continuously. Add it only if
tombstone rebuilds prove too disruptive in practice.

---

## 7. API pitfalls

1. **Calibrating after some inserts.** The first vectors then encode with
   different params than the rest. Calibrate strictly before the first `add`.
2. **Normalizing for cosine on insert but not query (or vice versa).** Both paths
   must normalize identically, before encoding.
3. **`ef < K`.** You can't return `K` from a smaller result list (HNSW guide §7).
   Clamp `ef = max(ef, K)`.
4. **Returning quantized distances to the user.** Expose float32 rerank distances
   only; quantized values are ranking-internal approximations.
5. **Tombstones not over-fetched.** If many candidates are tombstoned, fetching
   exactly `rerank_k` can leave fewer than `K` live results. Over-fetch by the
   tombstone count (or a margin) before filtering.
6. **Mutating during concurrent search without a model.** Decide the concurrency
   contract explicitly (HNSW guide §6.8); silent races corrupt the graph.
