# 05 — ANN-Benchmarks Harness

How to measure the DB the way the field does: recall vs. throughput curves on
standard datasets, against an exact ground truth. Two levels: a **self-contained
harness** you control (recommended first), and the **official ann-benchmarks
adapter** for apples-to-apples comparison with FAISS/hnswlib/etc.

---

## 1. Datasets and their format

ANN-Benchmarks ships datasets as **HDF5** files with a fixed schema:

| Dataset key | Shape | Meaning |
|---|---|---|
| `train` | `(N, D)` float32 | vectors to index |
| `test` | `(Q, D)` float32 | query vectors (held out) |
| `neighbors` | `(Q, 100)` int | ground-truth nearest-neighbour ids per query |
| `distances` | `(Q, 100)` float32 | their true distances |
| attr `distance` | string | `"euclidean"` or `"angular"` (cosine) |

Common ones, by metric and difficulty:

| Dataset | N | D | Metric | Notes |
|---|---|---|---|---|
| SIFT-1M | 1,000,000 | 128 | euclidean | values already ~0–255; global SQ shines |
| GIST-1M | 1,000,000 | 960 | euclidean | high-dim, heavier |
| GloVe-100 | ~1.18M | 100 | angular | text embeddings; normalize for cosine |
| Fashion-MNIST | 60,000 | 784 | euclidean | small, fast to iterate on |
| NYTimes-256 | ~290k | 256 | angular | mid-size angular |

Start on **Fashion-MNIST** or a **SIFT-1M subset** (first 100–200k rows) to keep
iteration under a minute, then scale up.

```python
import h5py, numpy as np
f = h5py.File("fashion-mnist-784-euclidean.hdf5", "r")
train, test = f["train"][:], f["test"][:]
gt          = f["neighbors"][:]              # (Q, 100) true ids
metric      = "cosine" if f.attrs["distance"] == "angular" else "l2"
```

The `distance` attribute drives your index's `metric` (the value passed to the
HNSW `distance=` path): `"angular"` → cosine (the wrapper unit-normalizes train
and test before indexing/querying), `"euclidean"` → L2. The HDF5 `neighbors`
ground truth is computed in the dataset's *true float* metric, so recall measures
your quantization error and HNSW approximation together — exactly what you want.
If you build your own ground truth instead of using the file's, compute it with
the true float metric (L2, or cosine on unit-normalized vectors), never with the
quantized kernel.

---

## 2. The metrics you report

- **Recall@K** = mean over queries of `|returned_topK ∩ groundtruth_topK| / K`.
  This is the *quality* axis. Standard reporting K is 10.
- **QPS** = queries / second (single-thread or stated thread count). The *speed*
  axis. Report build time separately.
- The result is a **curve**, not a point: sweep a query knob (`ef`, and here also
  `rerank_k`) to trace recall↑ as QPS↓, and plot recall (x) vs QPS (y, log scale).
  Higher/right is better. This is exactly the recall/cost tradeoff the HNSW guide
  §9 describes, now end-to-end through quantization + rerank.

Note ANN-Benchmarks uses recall against the *exact* ground truth in the file, so
both your quantization error and your HNSW approximation are folded into one
number — which is what you want to report.

---

## 3. Self-contained harness

Full control, no framework. Build once, sweep query params, plot.

```python
def recall_at_k(index, test, gt, K, ef, rerank_k):
    hits = 0
    t0 = time.perf_counter()
    for q, truth in zip(test, gt[:, :K]):
        got = index.search(q, K, ef=ef, rerank_k=rerank_k)
        hits += len(set(got) & set(truth.tolist()))
    qps = len(test) / (time.perf_counter() - t0)
    return hits / (len(test) * K), qps

# build once
idx = VectorIndex(dim=train.shape[1], metric=metric,
                  M=16, efConstruction=200, keep_floats=True)
t0 = time.perf_counter()
idx.build(keys=range(len(train)), vectors=train)
build_s = time.perf_counter() - t0

# sweep the query knobs -> the curve
for ef in (10, 20, 40, 80, 160, 320):
    for rk in (ef, 2 * ef):
        r, qps = recall_at_k(idx, test, gt, K=10, ef=ef, rerank_k=rk)
        print(f"ef={ef:4d} rerank_k={rk:4d}  recall@10={r:.4f}  qps={qps:7.1f}")
```

Because `keys=range(len(train))`, internal ids equal dataset row indices and the
returned keys compare directly to `gt`. Sweeping both `ef` and `rerank_k` shows
the two distinct recall levers: `ef` widens the graph search; `rerank_k` widens
the float32 rescue. Plot recall vs QPS to see which buys recall more cheaply on
your data.

---

## 4. Official ann-benchmarks adapter

To compare against the library's baselines, implement its algorithm interface
(`ann_benchmarks/algorithms/<yours>/module.py`) and register it. The contract:

```python
from ann_benchmarks.algorithms.base.module import BaseANN

class MyVectorDB(BaseANN):
    def __init__(self, metric, M, efConstruction):
        self._metric = "cosine" if metric == "angular" else "l2"
        self._M, self._efc = M, efConstruction
        self._ef = None

    def fit(self, X):                      # X: (N, D) float32 train set
        self.index = VectorIndex(dim=X.shape[1], metric=self._metric,
                                 M=self._M, efConstruction=self._efc,
                                 keep_floats=True)
        self.index.build(keys=range(len(X)), vectors=X)

    def set_query_arguments(self, ef, rerank_k=None):
        self._ef = ef
        self._rk = rerank_k or ef          # query-time knobs, no refit

    def query(self, v, n):                 # one query, return n internal ids
        return self.index.search(v, n, ef=self._ef, rerank_k=self._rk)

    def __str__(self):
        return f"MyVectorDB(M={self._M},efc={self._efc},ef={self._ef})"
```

Plus a `config.yml` declaring the constructor args (`M`, `efConstruction`) and the
swept `query_args` (`ef`, `rerank_k`). The framework then builds one index per
constructor combo and calls `set_query_arguments` across the query sweep — which
is exactly why `ef`/`rerank_k` must be runtime-only (no rebuild). The framework
handles ground truth, recall, QPS, and plotting.

**Key contract points:**

- `fit` builds the whole index (calibration + insert) from `X`.
- `query` returns up to `n` ids ranked best-first; ids are train-row indices.
- `set_query_arguments` changes only query-time behavior — never rebuilds.
- Constructor args (build-time) vs query args (runtime) must match the build/query
  split in doc 04 §5, or the framework's batched runs will be wrong.

---

## 5. What to expect and how to read it

- **Quantization costs a little recall** vs a float HNSW at the same `ef` — that's
  the point of measuring. Reranking should pull it back to within a small margin
  of float HNSW. If it doesn't, suspect calibration/clipping (doc 01 §10) before
  blaming HNSW.
- **Three diagnostic curves** make bugs obvious (doc 01 §7): float-HNSW (no
  quantization) bounds the achievable recall; codes-only (no rerank) shows pure
  quantization loss; codes+rerank is your shipping curve. They should nest in
  that order.
- **Pure-Python QPS will be low** vs compiled baselines — expected. Report it, but
  judge *recall* and the *shape* of the curve for correctness; judge QPS only
  after the numpy/typed-array optimizations (HNSW guide §6.3, doc 03 §2).
- **A recall cliff** at higher `ef` (recall stops climbing or drops) usually means
  an HNSW invariant is violated (asymmetric edges, skipped shrink, `Mmax0=M`) —
  re-check the HNSW guide's points to remember, not the quantizer.

---

## 6. Harness pitfalls

1. **Wrong metric vs the dataset attribute.** `angular` needs cosine
   (normalization); running it as L2 silently wrecks recall. Read `f.attrs`.
2. **Comparing against the wrong ground-truth K.** `gt` holds 100 neighbours;
   slice `gt[:, :K]` to match your `K`.
3. **Counting build time as query time.** Build once outside the QPS timer; time
   only `query`.
4. **`rerank_k`/`ef` baked into the constructor.** They must be query args, or the
   framework can't sweep them without rebuilding — and your curve collapses to
   points.
5. **Calibrating on `test`.** Fit the quantizer on `train` only; calibrating on
   queries leaks and misrepresents recall.
6. **Returning internal ids that aren't dataset rows.** With `keys=range(N)` they
   coincide; if you ever remap, translate back before comparing to `gt`.
7. **Single warm/cold run only.** QPS varies run to run; average a few query
   passes and report the build seed for reproducibility (the level RNG is
   seedable — HNSW guide §7 point 9).
